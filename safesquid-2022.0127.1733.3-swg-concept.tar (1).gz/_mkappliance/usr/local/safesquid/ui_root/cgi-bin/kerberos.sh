#!/bin/bash
#This script will help in setup kerberos 
#This script can be used for both ui as well as command line
. /opt/safesquid/safesquid_params.sh && EXPORT_INI

set -o pipefail

_KDESTROY=$(which kdestroy)
_KINIT=$(which kinit)
_MSKTUTIL=/usr/local/bin/msktutil
_KTUTIL=$(which ktutil)
_KLIST=$(which klist)

_AD_USER=""
MY_COMPUTER_NAME="$(hostname -s)"
MY_FQDN="$(hostname -f)"

LOG()
{
	cat - | tee -a /tmp/safesquid/kerberos
	echo -ne "kerberos : ${*}" | tee -a /tmp/safesquid/kerberos
}

DO_KDESTROY()
{
	RET=1
	${_KDESTROY} --all |& LOG && RET=0	
	[ "x${RET}"  == "x1" ] && LOG "${_KDESTROY}: failed\n" && return;
	 LOG "${_KDESTROY}: successful\n"
}


KINIT_USER()
{		
	RET=1
	echo ${LDAP_PASSWORD} | ${_KINIT} --password-file=STDIN  ${_AD_USER} |& LOG && RET=0
	[ "x${RET}" == "x1" ] && LOG "${_KINIT}: failed\n" && return 1;
	
	LOG "${_KINIT}: successful\n" 
	return 0 ;
}


RUN_MSKTUTIL()
{
	RET=1
	declare -a OPTS
	OPTS=();
	#msktutil dependency-check.
	LOG "Generate Keytab: calling RUN_MSKTUTIL\n"
	[ ! -f "${_MSKTUTIL}" ] && LOG "library: ${_MSKTUTIL}: not found\n" && return ${RET};
    PAKG=$( ldd ${_MSKTUTIL} | grep "not found" )
    [ "x${PAKG}" != "x" ] && LOG "library:${PAKG}\n" && return ${RET};
	
	export MSKTUTIL_KEYTAB=${KRB5_KTNAME}
	
	[ -f ${KRB5_KTNAME} ] && OPTS+=("--update") || OPTS+=("--create")
	
	REALM=${AD_DOMAIN^^}
	
	OPTS+=(--verbose)
	OPTS+=(--base 'CN=COMPUTERS')
	OPTS+=(--service HTTP/${MY_FQDN})
	OPTS+=(--keytab ${KRB5_KTNAME})
	OPTS+=(--computer-name ${MY_COMPUTER_NAME})
	OPTS+=(--upn HTTP/${MY_FQDN})
	OPTS+=(--server ${AD_FQDN})
	OPTS+=(--no-reverse-lookups)
	OPTS+=(--realm ${REALM})	
	
	LOG "${_MSKTUTIL} ${OPTS[*]}"
	${_MSKTUTIL} ${OPTS[*]} |& LOG && RET=0
	
	return ${RET};
	
	
	MODE="--create"

	[ -f ${KRB5_KTNAME} ] && MODE="--update"
	
	export MSKTUTIL_KEYTAB=${KRB5_KTNAME}
	
	LOG "${_MSKTUTIL} ${MODE} --verbose --base 'CN=COMPUTERS' --service HTTP/${MY_FQDN} --keytab ${KRB5_KTNAME} --computer-name ${MY_COMPUTER_NAME} --upn HTTP/${MY_FQDN} --server ${AD_FQDN} --no-reverse-lookups --realm ${AD_DOMAIN^^}\n"	
	${_MSKTUTIL} ${MODE} --verbose --base 'CN=COMPUTERS' --service HTTP/${MY_FQDN} --keytab ${KRB5_KTNAME} --computer-name ${MY_COMPUTER_NAME} --upn HTTP/${MY_FQDN} --server ${AD_FQDN} --no-reverse-lookups --realm ${AD_DOMAIN^^} 2>&1 | LOG
	
	RET=$?
	
	[ "x${RET}" == "x1" ] && return 1 ;
	
	LOG "MSKTUTIL: success[${RET}]\n"
	
	return 0;
}

CHECK_CONNECTIVITY()
{
	LOG "CHECK_CONNECTIVITY: $*\n"	
	for ((i = 0 ; i < 5 ; i++)); do
		host $* |& LOG && return 0;
	done	
	return 1
}

VAR_SETUP ()
{

	[ "x${KRB5_CONFIG}" == "x" ] && LOG "KRB5_CONFIG: not specified" && return 1;
	LOG "KRB5_CONFIG: ${KRB5_CONFIG}\n"
	
	[ "x${KRB5_KTNAME}" == "x" ] && LOG "KRB5_KTNAME: not specified" && return 1;
	LOG "KRB5_KTNAME: ${KRB5_KTNAME}\n"
	
	[ "x${AD_FQDN}" == "x" ] && LOG "AD_FQDN: not specified" && return 1;
	LOG "AD_FQDN: ${AD_FQDN}\n"
	
	CHECK_CONNECTIVITY ${AD_FQDN} ; RET=$? 
	[ "x${RET}" != "x0" ] && LOG "lookup: failed AD_FQDN: ${AD_FQDN}\n" && return 1
	
	[ "x${LDAP_USER}" == "x" ] && LOG "LDAP_USER: not provided\n" && return 1;
	LOG "LDAP_USER: ${LDAP_USER}\n"
	
	[ "x${LDAP_PASSWORD}" == "x" ] && LOG "LDAP_PASSWORD: not provided\n" && return 1;	
	[ "x${AD_DOMAIN}" == "x" ] && LOG "AD_DOMAIN: not provided\n" && return 1;
	LOG "AD_DOMAIN: ${AD_DOMAIN}\n"

	[ ! -f "${KRB5_CONFIG}" ] && LOG "KRB5_CONFIG: not found\n" && return 1;
	nslookup ${AD_FQDN} ; RET=$? 
	[ "x${RET}" == "x1" ] && LOG "nslookup: failed AD_FQDN: ${AD_FQDN}\n" && return 1
	
	_AD_USER="${LDAP_USER}@${AD_DOMAIN^^}"
	#MY_DOMAIN=`echo "${AD_DOMAIN}" | tr '[A-Z]' '[a-z]'`
	MY_DOMAIN=${AD_DOMAIN,,}
	MY_FQDN="${MY_COMPUTER_NAME}.${MY_DOMAIN}"
	
	LOG "MY_FQDN: ${MY_FQDN}\n"
	
	CHECK_CONNECTIVITY ${MY_FQDN} ${AD_FQDN}
	RET=$? 
	[ "x${RET}" != "x0" ] && LOG "lookup: failed MY_FQDN: ${MY_FQDN}\n" && return 1

#	ntpdate -p 1 -q ${AD_FQDN} ; ret=$?
	
}

MERGE_KEYTABS ()
{
	[ ! -f ${KRB5_KTNAME} ] && LOG "${KRB5_KTNAME}: not found"
	
	${_KLIST} -l |& LOG
	
	${_KTUTIL} copy ${KRB5_KTNAME} ${HTTP_KEYTAB} |& LOG
}


MAIN()
{	

	LOG "\n#############\n"
	
	HTTP_KEYTAB=${KRB5_KTNAME}	

	VAR_SETUP
	#should I deleted previously generated keytab?
	
#	DO_KDESTROY

	LOG "kinit user: _AD_USER: ${_AD_USER}\n"
	export KRB5_KTNAME=${HTTP_KEYTAB}.${MY_DOMAIN}

	KINIT_USER
	RET=$?		

	if [ "x${RET}" == "x0" ]
	then	
		LOG "kinit: successful\n" 
	else			
		LOG "kinit: failed\n" 
		return 1 ; 
	fi
	

	RUN_MSKTUTIL && LOG "MSKTUTIL: success\n" || LOG "MSKTUTIL: failed\n"

	MERGE_KEYTABS

	export KRB5_KTNAME=${HTTP_KEYTAB}

	[ "x${RET}" == "x0" ] && LOG "Generate Keytab: successful\n" && return 1 ;
	LOG "Generate Keytab: failed\n" 
	
}

MAIN 
