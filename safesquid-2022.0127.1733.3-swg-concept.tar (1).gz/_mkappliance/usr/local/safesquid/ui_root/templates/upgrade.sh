#!/bin/bash

_e=0
SH=$(which bash) ; _e=$? ; [ "x${_e}" == "x0"  ] || exit 0  
TAR=$(which tar) ; _e=$? ; [ "x${_e}" == "x0"  ] || exit 0  
_MONIT=$(which monit) ; _e=$? ; [ "x${_e}" == "x0"  ] || exit 0  

# UPDATE="/tmp/safesquid/upgrade"
STAGING="/tmp/staging"
SETUP_SCRIPT_DIR="_mkappliance/installation/"
SETUP_SCRIPT="setup.sh"
LOG="/var/log/syslog"

LOG_IT ()
{
	TIME=`date +"%Y %m %d %T"`
	echo "${TIME} [-1] safesquid upgrade: ${*}"
	
	return;
}



MONIT()
{
	LOG_IT "monit: $*"
	${_MONIT} $*
	return $?
}


UNMONITOR_SAFESQUID ()
{
	MONIT stop safesquid
}

MONITOR_SAFESQUID ()
{
	MONIT reload
	sleep 2
	MONIT start safesquid
#	MONIT monitor safesquid
}

DIE()
{
	[ "${STAGING}/" != "/" ] && [ -d "${STAGING}/" ] && rm -rf "${STAGING}/" ${UPGRADE_PACKAGE}
	exit 0
}

MAIN ()
{
#	[ -f ${UPDATE} ] || exit 0 # File that contains path of upgrade package not found
	
#	UPGRADE_PACKAGE=`<${UPDATE}`
	UPGRADE_PACKAGE=@UPGRADE_PACKAGE@
	
	[ "x${UPGRADE_PACKAGE}" == "x" ] && LOG_IT "upgrade package not set" && exit 0 # upgrade package not set
	
	[ ! -f "${UPGRADE_PACKAGE}" ] && LOG_IT "upgrade package not found" && exit 0 # upgrade package not found
	
	[ "${STAGING}/" == "/" ] && LOG_IT "staging folder not specified" && exit 0 # staging folder not specified
	
	[ ! -d "${STAGING}/" ] && LOG_IT "creating staging folder" && mkdir "${STAGING}" # create staging folder if not exists
	[ ! -d "${STAGING}/" ] && LOG_IT "failed to create staging folder" && exit 0 # failed to create staging folder
	
	${TAR} -zxvf "${UPGRADE_PACKAGE}" -C "${STAGING}/" ; _e=$?
	
	[ "x${_e}" != "x0" ] && LOG_IT "failed to extract tar contents" && DIE # failed to extract tar contents
	
	[ ! -f "${STAGING}/${SETUP_SCRIPT_DIR}${SETUP_SCRIPT}" ] && LOG_IT "setup script not found" && DIE # setup script not found
	
	UNMONITOR_SAFESQUID
	cd "${STAGING}/${SETUP_SCRIPT_DIR}"
	${SH} "${SETUP_SCRIPT}"
	
	MONITOR_SAFESQUID
	
	DIE
}

MAIN
