#!/bin/bash
# called by _USER_ to perform the necessary updation
# perform the process of updating the files in the safesquid folder
# ACTION(s) performed : softlink, mkdir, copy with overwite, copy without overwrite
# OWNERSHIP and PERMISSIONS will also be set

set -o pipefail

CWD=`dirname $0`
IAM=`basename $0`
DIST=""
_USER_="ssquid"
_GROUP_="root"
OWNER="${_USER_}:${_GROUP_}"

[ "x${CWD}" == "x." ] && CWD=`pwd`

PARENT_DIR=`dirname ${CWD}`

LIST=${CWD}"/list.conf";
OLD_FILES=${CWD}"/old.conf";
LOGF="/tmp/setup.log";
DATE=`date`;
L=0;

LOG()
{
	echo "${DATE} - ${*}" 
}

DIE()
{
	LOG "FATAL ERROR: ${*}"	
	LOG "Please Report this to the SafeSquid Tech Support"
	exit
}

WHICH_PLATFORM ()
{
	which aptitude && DIST="DB" && LOG "platform: Debian" && return;
	which apt-get && DIST="DB" && LOG "platform: Debian" && return;
	which yum && DIST="RH" && LOG "platform: Red-Hat" && return;
	DIE "platform: unknown"
}

MAKE_USER_ ()
{

		ID=""; 
		unset GID;
		typeset -a GID;
		unset G; typeset -i G; G=1
		
		useradd -r ${_USER_} -g ${_GROUP_} --shell ${SHELL}
		usermod ${_USER_} -g ${_GROUP_}
		ID=`id -un ${_USER_} 2> /dev/null` || DIE "cannot create _USER_: ${_USER_}"		
		GID=( `id -Gn ${_USER_} 2> /dev/null` ) || DIE "cannot check usergroup: ${_USER_}"

		for grps in ${GID[*]}
		do
			[ "x${grps}" != "x${_GROUP_}" ] && continue;			
			echo "_USER_ ${_USER_} is a member of _GROUP_ ${_GROUP_}" && G=0 && break;			
		done
		
		[ "x${G}" != "x0" ] && DIE "cannot add _USER_:${_USER_} to _GROUP_:${_GROUP_}"		
		
		return;
}

READ_SOURCE()
{
	source ${LIST}
}

MAKE_DIRECTORIES()
{
	for((i=0;i<${#DEST_DIR[*]};i++))
	do
		[ -d ${DEST_DIR[$i]} ] && continue;
		mkdir -p ${DEST_DIR[$i]}
		[ "x${PERMISSION_DIR[$i]}" == "x" ] && continue;
		chown -R --changes ${OWNER} "${DEST_DIR[$i]}"
		chmod --changes ${PERMISSION_DIR[$i]} "${DEST_DIR[$i]}"
	done

}

COPY_FILES()
{
	for((i=0;i<${#DEST_FILE[*]};i++))
	do
		[ -f "${PARENT_DIR}/${DEST_FILE[$i]}" ] && cp -R "${PARENT_DIR}/${DEST_FILE[$i]}" "${DEST_FILE[$i]}"
		[ "x${PERMISSION_FILE[$i]}" == "x" ] && continue
		[ -f "${DEST_FILE[$i]}" ] || continue
		chown -R --changes ${OWNER} "${DEST_FILE[$i]}"
		chmod --changes ${PERMISSION_FILE[$i]} "${DEST_FILE[$i]}"
	done

}

MAKE_LINKS()
{
	for((i=0;i<${#TARGET[*]};i++))
	do	
		ln -fs "${TARGET[$i]}" "${S_LINK[$i]}" 
	done
}

DEBIAN_INSTALLATION()
{	
	declare -a PACKS
	PACKS+=( `< ${CWD}/dependencies.lst` )
	PACKS+=( `< ${CWD}/system_dependnecies.lst` )
	
	if [ "x${PACKS}" != "x" ]; then
		export DEBIAN_FRONTEND=noninteractive
		aptitude -q -y install ${PACKS[*]}
		export DEBIAN_FRONTEND=
	fi	
}

REDHAT_INSTALLATION()
{	
	PACKS=`< ${CWD}/rh_dependencies.lst`	
	
	if [ "x${PACKS}" != "x" ]; then
		yum install ${PACKS}
	fi
}

INSTALL_PACKAGES()
{	
	[ "x${DIST}" == "x" ] && DIE "platform: unknown"
	[ "x${DIST}" == "xDB" ] && DEBIAN_INSTALLATION && return;
	[ "x${DIST}" == "xRH" ] && REDHAT_INSTALLATION && return;	
}

MAKE_CHANGES()
{
	HOSTNM="HOSTNAME\=\"`hostname -f`\""
	DOMAIN="DOMAIN\=\"`hostname -d`\""

	sed -i "s/HOSTNAME\=\"\"/${HOSTNM}/g"  /opt/safesquid/default/startup.ini
	sed -i "s/DOMAIN\=\"\"/${DOMAIN}/g" /opt/safesquid/default/startup.ini

	chmod 755 /etc/init.d/tcp_tune.sh

	[ -f /opt/safesquid/startup.ini ] && sed -i 's/;/#/g' /opt/safesquid/startup.ini

	chown -R --changes ${OWNER} /usr/local/safesquid 
	chown -R --changes ${OWNER} /var/db/safesquid   
	chown -R --changes ${OWNER} /var/log/safesquid 
	chown -R --changes ${OWNER} /var/cache/safesquid
	chmod 644 /etc/shadow
}

READ_OLD()
{
	source ${OLD_FILES}
}

REMOVE_OLD()
{
	for (( i=0; i<${#OLD[*]}; i++))
	do
		[ "x${OLD[$i]}" == "x" ] && continue;
		[ ! -e  "${OLD[$i]}" ] && continue;
		rm -f "${OLD[$i]}"	
	done
}

MAIN()
{
	WHICH_PLATFORM
	MAKE_USER_
	READ_OLD
	REMOVE_OLD
	INSTALL_PACKAGES	
	READ_SOURCE
	MAKE_DIRECTORIES
	COPY_FILES
	MAKE_LINKS
	MAKE_CHANGES
}


> ${LOGF};

MAIN |& tee -a ${LOGF};
chown ${OWNER} ${LOGF}
